<?php

namespace Kamansoft\KlorchidCms;

class KlorchidCms
{
    // Build your next great package.
}
